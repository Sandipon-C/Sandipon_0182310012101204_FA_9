package com.example.id_fa_9

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
